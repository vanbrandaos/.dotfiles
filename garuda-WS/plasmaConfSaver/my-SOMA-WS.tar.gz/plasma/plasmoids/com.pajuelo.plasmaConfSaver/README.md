PlasmaConfSaver
===========

This is a plasma 5 widget that allows you to save your current desktop layout configuration and restore previous saved layouts on the fly.

REQUERIMENTS:
spectacle
kdialog
Konsole
Qt.labs.platform

Please, if you like the work i do, consider making a donation to support my work! Thaks you!</br>
[![paypal](https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif)](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=RLHBW9ET7FLP4)

